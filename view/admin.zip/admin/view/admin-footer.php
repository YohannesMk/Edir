          <footer class="footer text-center">
          2022 © Edir Admin Site
        </footer>
    </div>
</div>
<script src="plugins/bower_components/jquery/dist/jquery.min.js"></script>

<script src="bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/app-style-switcher.js"></script>

<script src="js/waves.js"></script>
<script src="js/sidebarmenu.js"></script>

<script src="js/custom.js"></script>
<script src="../resources/js/jquery.min.js"></script>
<script src="../resources/js/bootstrap.bundle.min.js"></script>
<script src="../resources/js/bootstrap-input-spinner.js"></script>
<script src="../resources/js/jquery.waypoints.min.js"></script>
<script src="../resources/js/main.js"></script>
</body>

</html>